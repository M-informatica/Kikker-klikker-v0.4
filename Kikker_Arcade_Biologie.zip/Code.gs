// Code.gs

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('Mijn website')
    .addItem('Open website', 'openWebsite')
    .addToUi();
}

function openWebsite() {
  var html = HtmlService.createHtmlOutputFromFile('index')
    .setWidth(1200)
    .setHeight(800)
    .setTitle('Kikker Arcade - Biologie Educatief');

  SpreadsheetApp.getUi().showModalDialog(html, 'Kikker Arcade');
}

function doGet() {
  return HtmlService.createHtmlOutputFromFile('index')
    .setTitle('Kikker Arcade - Biologie Educatief')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}
